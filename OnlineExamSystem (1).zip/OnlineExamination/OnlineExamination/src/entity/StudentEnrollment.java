package entity;

import java.util.Date;

public class StudentEnrollment {
	private int enrollmentId;
	private int studentId;
	private int courseId;
	private String batchName;
	private Date enrollmentDate;
	private Date completionDate;
	private boolean status;

}
