package entity;

public class Admin {
	private String UserName;
	private String Password;
}
