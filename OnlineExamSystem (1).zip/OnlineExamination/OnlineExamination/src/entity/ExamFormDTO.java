package entity;

public class ExamFormDTO {
	private int questionNo;
	private int marked_option;
	private int testPaperCode;
	private int examRollNo;

}
