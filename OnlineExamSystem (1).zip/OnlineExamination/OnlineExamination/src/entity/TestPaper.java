package entity;

public class TestPaper {
	private int testPaperCode;
	private String difficultyLevel;
	private int courseId;
	private String description;

}
