package entity;

public class Course {
	private int courseId;
	private String CourseName;
	private String courseType;
	private String Description;
	
}
