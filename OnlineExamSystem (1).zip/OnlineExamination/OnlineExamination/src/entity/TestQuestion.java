package entity;

public class TestQuestion {
	private int id;
	private String question;
	private int option1;
	private int option2;
	private int option3;
	private int option4;
	private int correctAnswer;
	private int questionNo;
	private int testPaperCode;
	
}
