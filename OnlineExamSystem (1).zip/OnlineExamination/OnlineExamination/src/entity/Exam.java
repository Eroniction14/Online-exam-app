package entity;

import java.util.Date;
import java.util.Timer;

public class Exam {
	private int examRollNo;
	private int testPaperCode;
	private int enrollmentId;
	private Date dateOfExam;
	private boolean status;
	private int MaximumScore;
	private int actualScore;
	private Timer examDuration;
	private String difficultyLevel;
	private boolean isAnnouncedToStudent;
	
	
	
	

}
