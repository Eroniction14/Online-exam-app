package entity;

public class Student {
	private String studentId;
	private String username;
	private String password;
	private String firstName;
	private String lastName;
	private String Gender;
	private String Email;
	private String mobileNo;

}
